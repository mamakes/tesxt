---
# Use the Intro widget of the Blog template
widget: starter.blog.intro

# This file represents a page section.
headless: true

# Order that this section will appear in.
weight: 10

title: ✏️ Blog Template
subtitle: 'For [Wowchemy Website Builder](https://wowchemy.com/)'

design:
  background:
    color: '#090a0b'
    text_color_light: true
---
